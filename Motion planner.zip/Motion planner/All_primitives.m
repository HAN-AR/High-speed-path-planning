     
% This file is used to add the motion primitives used for path planning to
% the workspace.
clear all;
clc
thetad=linspace(0,180,2); %disritized in 30 degree
%thetad=0
%thetad=[270 300 330 0 30 60 90]
%thetad  =   [270 315 320 325 330 335 340 345 350 355 0 5 10 15 20 25 30 35 40 45 90];     % Creating discretized orientation angle 5 degree 
count   =   0;                      % Counting teh number of primitives created
yd = [0.5,-0.5,1,-1,2,-2,3,-3,3.5,-3.5,4,-4,5,-5,6,-6];
% deltad  =   [-10 0 10];             % Creating discretized steering angle
%% Loading the MP with initial theta=0
for j= 1 : length(yd)
    % Take the motion primitive from the motion primitive bank
    folder = strcat('Motion_primitives_example\theta_',num2str(0),'delta0');
    for k=1:length(thetad)
      % deltadm=0;
        for m=1:length(yd)
            %file = strcat(folder,'\','mp_',num2str(thetad(k)),'_',num2str(deltad(m)),'.mat');
            file=strcat(folder,'\','mp_y=',num2str(yd(m)),'.mat');
            % Check if the motion primitve exists
            if exist(file,'file') 
                load(file);
                count=count+1;
                x_0(:,count)    =   out.STATES(:,2);
                y_0(:,count)    =   out.STATES(:,3);
                t_0(:,count)    =   out.STATES(:,4);
                d_0(:,count)    =   out.STATES(:,5);
                %k_0(:,count)    =   out.STATES(:,6);
                time_0(1,count) =   out.PARAMETERS(1,2);
            end
        end
    end 
    end
% %% Repacing the straight motion primitive
% % Finding straight primitives
checkti     =  0==t_0(21,:);
checkdi     =   0==d_0(21,:);
checktf     =   0==t_0(21,:);
checkdf     =   0==d_0(21,:); 
cond        =   all([checkdi]);
index       =   find(cond);
%%
% Deleting straight primitives
x_0(:,index)    =   [];
y_0(:,index)    =   [];
t_0(:,index)    =   [];
%k_0(:,index)    =   [];t
d_0(:,index)    =   [];
time_0(:,index) =   [];
%% Creating straight motion primitiv
% Creating straight motion primitive of different length
%x_gen=[0.1 0.2 0.3 0.4 0.5 0.7 1 1.5 2 2.5 3 3.5 4 5 6 7 8 9 10 15 20];
x_gen=[0.5 1 2 3 4 5 6 7 8 9 10 15 20 30 40];
for i=1:length(x_gen)
 xgen    =   linspace(0,x_gen(i),21);
 ygen    =   zeros(1,21);
 count   =   length(x_0(1,:));
 count   =   count+1;
 x_0(:,count)    =   xgen(1,:)';
 y_0(:,count)    =   ygen';
zer     =   zeros(21,1);
%k_0(:,count)    =   zer;
d_0(:,count)    =   zer;
t_0(:,count)    =   zer;
time_0(count)   =   8; 
end
% Adding the initial theta=0 primitives into the real motion primitive bank 
x   =   x_0;
y   =   y_0;
t   =   t_0;
%k   =   k_0;
d   =   d_0;
time    =   time_0;
%% Rotating the MP all around to create other states
count_x     =   length(x_0(1,:)) ; %Taking the length of the x matrix
%thetad=linspace(0,357,11);
for j   =   2:1:length(thetad)  %For all discreet thetas
    % rot is the rotational matrix used to rotate the motion primitives
    rot     =   [cosd(-thetad(j)) -sind(-thetad(j)); sind(-thetad(j)) cosd(-thetad(j))];   
    for i   =   1:length(x_0(1,:))
        temxy   =   [x_0(:,i) y_0(:,i)]*rot;
        count_x     =   count_x+1;  % Updating Count
        % Adding the rotated MP to the MP bank.
        x(:,count_x)    =   temxy(:,1);
        y(:,count_x)    =   temxy(:,2);
        t(:,count_x)    =   t_0(:,i)+deg2rad(thetad(j));
        d(:,count_x)    =   d_0(:,i);
        time(count_x)   =   time_0(i);
        
    end
end
%% Initializing state check vectors (tini,tfin,gini,gfin,xfin,yfin). This 
% done so that we can identify the motion primitives by their initial and 
% final states. 
tini    =   t(1,:);
tfin    =   t(length(t(:,1)),:);
dini    =   d(1,:);
dfin    =   d(length(d(:,1)),:);
xfin    =   x(length(x(:,1)),:);
yfin    =   y(length(y(:,1)),:);
tini    =   rad2deg(tini);
tfin    =   rad2deg(tfin);
dini    =   rad2deg(dini);
dfin    =   rad2deg(dfin);
tini    =   round(tini*2)/2;
tfin    =   round(tfin*2)/2;
dini    =   round(dini);
dfin    =   round(dfin);
cost=time;
%%

tini        =  wrapTo360(tini);
tfin        =  mod(tfin,360);

clear  file folder  j out k m count count1 xgen ygen xygen zer rot time xgend indexvector thetad n j;
clear checkgf checkgi checktf checkdf checkdi checkti changef changer  cond count_0 count_x d_0 gammad index i deltad ;
clear temxy time_0   g_0 t_0;
%% Now genrated lattice are ready to use for planning and can be save as mat file
%% to check the generated motion primitives
thetad  = linspace(0,180,2);
%thetad  = 0;
deltad= 0;

 for j=1:length(thetad)
%    for k=1:length(deltad);
checkti=thetad(j)==tini;
checkdi=0==dini;
checky=y==0
cond = all([checkti;checkdi;checky]);
index= find(cond);
%  figure(1)

% plot(x(:,index),y(:,index),'black','Linewidth',2);

hold on
%end

 end
%  for j=1:length(thetad)
%    for k=1:length(deltad);
% checkti=thetad(j)==tini;
% checkdi=0==dini;
% 
% cond = all([checkti;checkdi]);
% index= find(cond);
%  figure(1)
% plot(x(:,index),y(:,index),'red','Linewidth',2);
% 
% hold on
% end
% 
%  end
%  
% xlabel('x (m)');ylabel('y(m)');
% %xlim([-50 50]);
% ylim([-6 6]);
% grid on;
% legend('Straight','Parallel');

%% now specific primitive can be select basis of following condition
checkti= 0==tini;
checkdi= 0==dini;
checktf= 0==tfin;
checkdf= 0==dfin;
cond = all([checkdi;checktf;checkdf]);
index= find(cond);
figure(1)
plot(x(:,index),y(:,index));
