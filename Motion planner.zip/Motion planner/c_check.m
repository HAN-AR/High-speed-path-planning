% This function calculates if an input leads to a state which is there 
%already in the closed list.If it is it skips the input.
function check = c_check(t_x,t_y,c,ip)
check = 1; % not in closed list
q=find(c>=1);
q1=c(q);
checkx= t_x(q1)==ip.x;
checky= t_y(q1)==ip.y;

cond = all([checkx;checky]);
cond = any(cond);
if cond
    check=0;
end
end
