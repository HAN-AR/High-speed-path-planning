function V=Velocity_profiler(xz,yz,zdir)
%to generate velocity profile
index=find((zdir==1));
index1=find((zdir==1));
 %path= interparc(1000,xz(index1,1),yz(index1,1),'linear');
 %%
 x2=xz(index1,1);
y2=yz(index1,1);
z2=zeros(length(y2),1);
%y2 = cos(linspace(0,3*pi));
X = [x2,y2,z2];
[L R2] = curvature(X);
k=1./R2;
 %%
s      =   (hypot(diff(xz(index1,1)),diff(yz(index1,1))));

 select = ~isnan( s )    ;  % Vector of logicals, true at location corresponding
                             %   to non-NaN elements of A.
 s = L ;
 sf=max(L);
 vmax=2.78;
 amax=1;
 dmax=-1;
 vf=0;
 vi=0;
 sa=((vmax)^2-(vi)^2)/(2*amax);
  sb=sf-((((vf)^2-(vmax)^2)/(2*dmax)));

  s1=0;
 
V=nan(length(s),1);
S=nan(length(s),1);

 for i=1:length(s)
   
    % i=i+1
    % Vk=sqrt(0.6/abs(k(i)))
     if k(i)<=max(k)
          Vk=sqrt(0.6/abs(max(k)));
      else
          Vk=vmax;
      end
     if (s(i)+(s1))<=sa
         v=sqrt((2*amax*s(i)+s1)+(vi)^2);
%          if i==1
%              v=0;
%             
%          end
     elseif (s(i)+(s1))>=sa && (s(i)+(s1))<=sb
         
         v=vmax;
     else (s(i)+(s1))>=sb && (s(i)+(s1))<=sf;
         
         v=sqrt(complex((2*(dmax)*((s(i)+s1)-sb))+(vmax)^2));
         v=real(v);
     end
    % s1=s(i)+s1
     V4=min(v,2);
     V3=min(Vk,v);
    V(i)=round(V3*3)/3;
     S(i)=s1;
  
 end
 %plot(L,-V*3.6)
% hold on
%V=smooth(V,10);
% Nsamps = length(x1);
% fc=3
% Fs=1/0.002 %sampling frequency 
% 
% t = (1/Fs)*(1:Nsamps);
% %V1=bandpass(x1,[1,3],Fs);
%  [b,a] = butter(5, 0.1,'low'); 
%  %fc = cutoff freq in Hz, fs = sample frequency in Hz
%  V1 = filter(b, a, x1); 
 %figure(3)
 %subplot(211)
 %plot(L+x2(1,1),V*3.6,'Linewidth',1.2)
 
 hold on
mu = vmax*3.6;
%hline = refline([0 mu]);
%hline.Color = 'r';
%  title('Trapezoidal Velocity Profile')
% xlabel ('path length (m)')
% ylabel ('Velocity (Km/h)')
%ylim([0 12])
%%
%path= interparc(500,xz(index1,1),yz(index1,1),V,L,'linear');
% path(:,1)=pchip(linspace(1,length(xz),length(xz)),xz,linspace(1,length(xz),length(xz)*5));
% path(:,2)=pchip(linspace(1,length(yz),length(yz)),yz,linspace(1,length(yz),length(yz)*5));
% path(:,4)=pchip(linspace(1,length(xz),length(xz)),V,linspace(1,length(xz),length(xz)*5));
% path(:,3)=pchip(linspace(1,length(xz),length(xz)),L,linspace(1,length(xz),length(xz)*5)); 
end