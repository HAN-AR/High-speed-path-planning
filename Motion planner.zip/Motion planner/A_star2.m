function [loopcheck,o, c, cc, cur, t_pred, i_state, x, y, t_predxy, t_x, t_xa, t_y, t_ya,  t_dir, t_count, t_hcost]=A_star2(cost,d,dfin,dini,t,tfin,tini,x,xfin,y,yfin,obsc,obsx,obsy,i_state,f_state)
dir1=1;
 mp      =   struct('ti',0,'di',0,'dir',0);  
%[ cur state f_state]=b_star(start,goal)
cur   =   struct('x',0,'y',0,'xa',0,'ya',0,'predxy',0,'tf',0,'df',0,'gcost',0,'hcost',0,'pred',mp);

% %% A* algorithm
% % A* algorithm lists
 % Open list
 oc  =   0;  % Open list count
 o=zeros(1,17000);
%close list
c=zeros(1,1000);

%cur             =   state;          % Current state in concideration
%
cur.x           =   i_state.x;      % Initializing cur to initial state 
cur.y           =   i_state.y;
cur.xa          =   i_state.x;
cur.ya          =   i_state.y;
cur.tf     =   i_state.t; 
cur.df     =   i_state.d;
cur.pred.dir    =   dir1;

% % Adding the initail state in the tree.
% % 
t_count=0;
t_x=zeros(1,17000);
t_y=zeros(1,17000);
t_xa   =   zeros(1,17000);
t_ya   =   zeros(1,17000);
t_predxy   =   zeros(1,17000);
t_gcost   =  zeros(1,17000);
t_hcost   = zeros(1,17000);
t_pred = zeros(1,17000);
t_dir  =  zeros(1,17000);

t_count     =   t_count+1;
t_x(t_count)=   cur.x;
t_y(t_count)=   cur.y;
t_xa(t_count)   =   cur.xa;
t_ya(t_count)   =   cur.ya;
t_predxy(t_count)   =   nan;
t_gcost(t_count)    =   nan;
t_hcost(t_count)    =   nan;
t_pred(t_count) =   nan;
t_dir(t_count)  =   nan;
% % 
% % Adding the inital state in the closed list
cc=0;

%c=zeros(size(cc))

 cc          =   cc+1;

 c(cc)       =   1;
% 
% %%
loopcheck = 1;  %Checks the final condition. Updated by function loop_check.m 
while loopcheck 
% index=ID(tini,dini) 
%index=index'
%      checkti     = cur.tf==tini;                                          % Selecting MP with initial states equal to the final state of the previous config
%     checkdi     =cur.df ==dini;
%     cond    =   all([checkti;checkdi]);                                   % Finding indexes of those MP in the MP bank
%      index   =   find(cond)                                               % Finding the coordinates of the required MP
index=find((tini==cur.tf & dini==cur.df));                                  % Selecting MP with initial states equal to the final state of the previous config
index=index';
    ifcheck =   ~isempty(index) ;
     if ifcheck
         for k   =   1:length(index) 
             %ip  =   state;                                                % Utilizing all of those MP
            ip   =   struct('x',0,'y',0,'xa',0,'ya',0,'predxy',0,'tf',0,'df',0,'gcost',0,'hcost',0,'pred',mp);
            ip.pred.ti  =   cur.tf;                                         % Creating the input state, initial theta
            ip.pred.di  =   cur.df;                                         % Creating the input state, initial delta
            ip.predxy   =   c(cc);
            if cur.pred.dir     ==  1                                      % Setting the direction of motion
               ip.pred.dir=1;
            end

            if cur.pred.dir     ==  -1
               ip.pred.dir=1;
            end 
            xp   = x(:,index(k));                                           % Extracting x and y data from mp bank.
            yp   = y(:,index(k));
            thetap = t(:,index(k));                                         % Extracting theta data from mp bank.
            deltap = d(:,index(k));                                         % Extracting delta data from mp bank.
           maxdelta=max(abs(deltap)); 
            dirp   = ip.pred.dir;                                           % Setting the direction for sending to functions
            ip.xa = cur.xa+xp(length(xp));                                  % Finding the end coordinates of the MP to find new state.
            ip.ya = cur.ya+yp(length(yp));
            ip.tf  =   tfin(index(k));                                     % Creating the input state, final theta 
            ip.df  =   dfin(index(k));                                     % Creating the input state, final delta
            ip.x = round(ip.xa);                                           % Rounding the values to fit the scale of the state space(if u wish to chang the resolution this has to be changed)
            ip.y = round(ip.ya);
          

            check_c       = c_check(t_x,t_y,c,ip);                          % Check if the input is in the closed list. 
            check_obstacle = obs_check(cur,xp,yp,thetap,deltap,dirp,obsc,obsx,obsy);
            cost1= cost(index(k)); 
            

            if check_c && check_obstacle
                ip.gcost = gcost(cur,cost1) ;                          % Function to calculate the gcost of ip
                ip.hcost =hcost2(ip,f_state,i_state);                            % Function to calculate the hcost of ip
                check_o       = o_check (t_x,t_y,t_gcost,ip,o,oc);          % Check if the state is already in open list
                if check_o
                    % Adding the state to the tree
                    t_count=t_count+1;
                    t_x(t_count)= ip.x;
                    t_y(t_count)= ip.y;
                    t_predxy(t_count)= ip.predxy;
                    t_xa(t_count)= ip.xa;
                    t_ya(t_count)= ip.ya;
                    t_pred(t_count)= index(k);
                    t_dir(t_count)= ip.pred.dir;
                    t_gcost(t_count)= ip.gcost;
                     if maxdelta>=0.35
                    t_hcost(t_count)= ip.hcost*150;                       %penalty for High steering angle
                    else
                        t_hcost(t_count)= ip.hcost;
                    end
                     %t_tf(t_count)=ip.pred.tf;
            
                    oc=oc+1;                                                % Updating open count
                    o(oc)=t_count ;                                         % Adding the index of the state to the open list
                    
                end
            end
        end
     end
     
     
      %% Exploring reverse paths
    
%  checkti= cur.tf==tfin;                                                     % Selecting MP with initial states equal to the final state of the previous config but with tfin and dfin (reverse)
%     checkdi= cur.df==dfin;
%     cond = all([checkti;checkdi]);                                          % Finding indexes of those MP in the MP bank
%     index= find(cond);                                                      % Finding the coordinates of the required MP
%     ifcheck = ~isempty(index);
     index=find((tfin==cur.tf & dfin==cur.df));                              % Selecting MP with initial states equal to the final state of the previous config but with tfin and dfin (reverse)
     index=index';
      ifcheck =   ~isempty(index) ;
    if ifcheck
        for k=1:length(index)
            ip   =   struct('x',0,'y',0,'xa',0,'ya',0,'predxy',0,'tf',0,'df',0,'gcost',0,'hcost',0,'pred',mp);
            ip.pred.ti  =   cur.tf;
            ip.pred.di  =   cur.df;
            ip.predxy   =   c(cc);
            if cur.pred.dir==1
               ip.pred.dir=-1;
            end
            if cur.pred.dir==-1
               ip.pred.dir=-1;
            end
            xp=x(:,index(k));
            yp=y(:,index(k));
            xfinr=xfin(index(k));
            yfinr=yfin(index(k));
            xp=xp-xfinr;
            yp=yp-yfinr; 
            thetap = t(:,index(k));
            deltap = d(:,index(k));
            dirp   = ip.pred.dir;
            ip.xa = cur.xa+xp(1);                                           % Finding the end coordinates of the MP to find the new state.
            ip.ya = cur.ya+yp(1); 
            ip.tf  =   tini(index(k));
            ip.df  =   dini(index(k));
            ip.x = ppround(ip.xa);                                          % Rounding the values to fit the scale of the state space
            ip.y = ppround(ip.ya);
            check_c       = c_check(t_x,t_y,c,ip);                          % Check if the input is in the closed list.
            cost1=cost(index(k)); 
            
            check_obstacle = obs_check(cur,xp,yp,thetap,deltap,dirp,obsc,obsx,obsy);
            %check_obstacle = obs_checker(cur,xp,yp,thetap,map);
            if check_c && check_obstacle
                ip.gcost = gcost(cur,cost1);                           % Function to calculate the gcost of ip
                [ip.hcost] =hcost2(ip,f_state,i_state);                            % Function to calculate the hcost of ip
                check_o       = o_check(t_x,t_y,t_gcost,ip,o,oc);           % Check if the state is already reached
                if check_o
                    t_count=t_count+1;
                    t_x(t_count)= ip.x;
                    t_y(t_count)= ip.y;
                    t_predxy(t_count)= ip.predxy;
                    t_xa(t_count)= ip.xa;
                    t_ya(t_count)= ip.ya;
                    t_pred(t_count)= index(k);
                    t_dir(t_count)= ip.pred.dir;
                    t_gcost(t_count)= ip.gcost;
                    t_hcost(t_count)= ip.hcost;
                    % t_k(t_count)=hk;
                    oc=oc+1;
                    o(oc)=t_count;
                    
                end
            end
        end
    end
 %%    
    q2=find(o>=1);
    q3=o(q2);
      tcostall= t_gcost(q3)+t_hcost(q3);
     [min_cost,min_ind]    = min(tcostall)  ;                                % Finding the state with the min cost
     cc         =   cc+1    ;                                               % Updating close list count 
     c(cc)      =   q3(min_ind) ;                                             % Puting it in closed list
    %o(min_ind) =   [];                                                      % Removing from open list
    j=find(o==(c(cc)));
    o(j)=zeros(1,1);
    
       %% Plot the explored graph real-time (to be deleted)
    index        =   t_pred(c(cc));
    if t_dir(c(cc))==1
        xp=x(:,index);
        yp   = y(:,index);
    else
        xp=x(:,index)-xfin(index);
        yp=y(:,index)-yfin(index);
    end
%     thetap = t(:,index);
%     deltap = d(:,index);
%     dirp   = t_dir(c(cc));
    pred_index= t_predxy(c(cc));
    xp= xp+t_xa(pred_index);
    yp= yp+t_ya(pred_index);
 figure(1);
plot(xp,yp,'c','Linewidth',0.1)
    drawnow
      hold on;
    cur.x           =   t_x(c(cc));                                         % Initializing cur to minimum cost state
    cur.y           =   t_y(c(cc));
    cur.xa          =   t_xa(c(cc));
    cur.ya          =   t_ya(c(cc));
    cur.predxy      =   t_predxy(c(cc));
    index           =   t_pred(c(cc));
    cur.pred.dir    =   t_dir(c(cc)); 
    cur.hcost  =   t_hcost(c(cc));
    cur.gcost  =   t_gcost(c(cc));
    if cur.pred.dir == 1
        cur.pred.ti     =   tini(index);
        cur.pred.di     =   dini(index);
        cur.tf     =   tfin(index);
        cur.df     =   dfin(index);
         %indexvector = [indexvector; index];
    else
        cur.pred.ti     =   tfin(index);
        cur.pred.di     =   dfin(index);
        cur.tf     =   tini(index);
        cur.df     =   dini(index);
     

    end

     loopcheck   = loop_check(cur,f_state);
 
 end