index=[1:11 1001:1139 2007:2105];
%    xg=out.path(index,1);
%    yg=out.path(index,2);
%    theta=out.path(index,3);
%    
   %%
   %
x2=out.SD_pos(:,1)';
y2=out.SD_pos(:,2)';
z2=zeros(length(y2),1); 
X = [x2',y2',z2];
[L2,R2] = curvature(X);
figure(1)
subplot(211)
%plot(L2,out.actual*3.6,'r')
hold on
plot(L2,out.SD_vel*3.6,'b')
 grid;
 xlabel('Path Length (m)');ylabel('Velocity[Km/hr]');
%%
figure(2)
subplot(211)
plot(out.path(:,1),out.path(:,2),'r','Linewidth',1.2)
 grid on;
 hold on
 plot(out.SD_pos(:,1),out.SD_pos(:,2),'--b','Linewidth',1.2)
  plot(out.SD_pos(:,3),out.SD_pos(:,4),':g','Linewidth',1)
%  scatter(90,3)
%  scatter(87.9,9.5)
  %xlim([75 96]);
    ylim([-8.5 8.5]);
        xlabel('x-position [m]');
ylabel('y-position [m]');
 title('Trajectory Tracking Controller')
 legend('Trajectory(ref)','Trajectory(Sim-Rear Axle)','Trajectory(Sim-Front Axle)')
 %%
 figure(3)
 subplot(211)
  hold on
%  plot(L2,rad2deg(steering),'r','Linewidth',1.2)
plot(L2,rad2deg(out.SD_angle(:,end)),'b','Linewidth',1.2)

  ylim([-35 35]);
   % xlim([0 54]);
    %set(gca,'ytick',[-30:10:30]);
  grid on;
  title('Steering Angle Input')
  legend('Steering Angle(Simulink)')
  xlabel ('Path Length [m]')
ylabel ('Steering angle [Degree]')
 
 %%
 %[points,errors1]= distance2curve(out.SD_pos(:,1:2),[xg(:,1),yg(:,1)],'linear');
%%
%  figure(2)
% subplot(211)
%  plot(L3,errors1,'b','Linewidth',1.2);
%  grid on;
%  xlabel('Path Length');ylabel('Error[m]','Linewidth',1.2);
% %   ylim([0 0.04]);
% %     xlim([0 102]);
% title('Lateral Error')
%   %  set(gca,'ytick',[-30:10:30]);
 %%
%  figure(3)
%  subplot(211)
% 
%  hold on
%  plot(L2,out.actual*3.6,'r','Linewidth',1.2)
%    plot(L2,ans*3.6,'b','Linewidth',1.2)
%   xlim([0 103]);
%   ylim([-5 12]);
%   title('Trapezoidal Velocity Profile')
%   legend('Velocity(ref)','Velocity(Gazebo)')
%   xlabel ('Path Length [m]')
% ylabel ('Velocity [Km/h]')
%    grid on;
   %%
%     path= interparc(60,x_path,y_path,t_path,'linear');
   %%
%    xg=out.path(index,1);
%    yg=out.path(index,2);
%    theta=out.path(index,3);
%    xc=[];
% yc=[];
%     for i=249
%         i
%         xp=xg(i,1);
%         yp=yg(i,1);
%         thetap=theta(i,1);
%            L_1f = 1.685; % Wheelbase of streetdrone 
%     oh_1b = 0.3;       % Longitudinal distance from the rear axle to the end of the vehicle [m] 
%     oh_1f = L_1f+0.3;  % Longitudinal distance from the rear axle to the front of the vehicle [m]
%     w_1   = 1.2;     % Width of streetdrone [m]
%     % Now  we will create vectors to each corner of the vehicle
%     % Length of vector 1, 2 is the same and 3,4 is the same
%     lv12_1 = hypot(oh_1b,(w_1/2)); % Length of Vector 1 and 2
%     lv34_1 = hypot((w_1/2),oh_1f); % Length of Vector 3 and 4
% 
%  
%     % For streetdrone
%     % Angle of the vectors
%     av1 = (180/pi*thetap)+90+atand(oh_1b/(w_1/2)); % Angle of Vector 1
%     av2 = (180/pi*thetap)-90-atand(oh_1b/(w_1/2)); % Angle of Vector 2
%     av3 = (180/pi*thetap)-atand((w_1/2)/oh_1f); % Angle of Vector 3
%     av4 = (180/pi*thetap)+atand((w_1/2)/oh_1f); % Angle of Vector 4
% 
%     % Finding the actual points
%     xv1_1 = xp+lv12_1*cosd(av1);
%     yv1_1 = yp+lv12_1*sind(av1);
%     xv2_1 = xp+lv12_1*cosd(av2);
%     yv2_1 = yp+lv12_1*sind(av2);
%     xv3_1 = xp+lv34_1*cosd(av3);
%     yv3_1 = yp+lv34_1*sind(av3);
%     xv4_1 = xp+lv34_1*cosd(av4);
%     yv4_1 = yp+lv34_1*sind(av4);
% 
%     
%     xc=[[xv1_1 xv2_1 xv3_1 xv4_1];xc];
%     yc=[[yv1_1 yv2_1 yv3_1 yv4_1];yc];
%       
% %         
%     end
%          for i=1:1:[length(xc(:,1))]
%         streetdrone= polyshape([xc(i,1);xc(i,2);xc(i,3);xc(i,4)],[yc(i,1);yc(i,2);yc(i,3);yc(i,4)]);
%              figure(1);
%             % subplot(211)
%         axis equal;
%            plot(streetdrone,'FaceColor','y','FaceAlpha',0.01);
%         drawnow;
%         hold on
%     end
% 
%   xlim([3 105]);
%  ylim([-8.5 3]);
% xlabel('x-position [m]');
% ylabel('y-position [m]');
% %%
% plot(xg(1:152,1),yg(1:152,1),'r','Linewidth',1.2)
% %%
% hold on
%  plot(out.path(1:1000,1),out.path(1:1000,2),'r','Linewidth',0.5)
% plot(out.path(1000:2000,1),out.path(1000:2000,2),'--m','Linewidth',0.5)
% hold on
% plot(out.path(2001:2042,1),out.path(2001:2042,2),'b','Linewidth',1.2)
% plot(out.path(2043:3000,1),out.path(2043:3000,2),'--b','Linewidth',1.2)
%%
% scatter(90.9,-6.4,'*b')
% scatter(15.02,0,'*m')
% scatter(5,0,'*r')
%  scatter(88.9,0,'*k')
% xlabel('x-position [m]');
% ylabel('y-position [m]');
%%
% figure(5)
% subplot(211)
% scatter(obsx2,obsy2,'k')
% hold on
% plot(CurV1(:,1),CurV1(:,2))
% hold on
% plot(unnamed3(:,1),unnamed3(:,2))
%%
%title(strcat('X_i=',num2str(5),', Y_i=',num2str(0),', \theta_i=',num2str(0),', X_f=',num2str(91),', Y_f=',num2str(-6.5),', \theta_f=',num2str(90),', Comp Time=',num2str(3.045),', Long_e=',num2str(0.07),', Lat_e=',num2str(0.1)));