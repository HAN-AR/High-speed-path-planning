% This function finds out if the current input state is already in the open list
% and finds if the cuttent way to it is better that what already exsists.
% If so we proceed to add this option to the state space.
function check = o_check(t_x,t_y,t_gcost,ip,o,oc)
check = 1;
% Finding if the state is already present.
q2=find(o>=1);
q3=o(q2);
checkx= t_x(q3)==ip.x;
checky= t_y(q3)==ip.y;
cond = all([checkx;checky]);
cond1 = any(cond); % checks if the previous copy of the state is in the open list
if cond1 && ~isempty(checkx)    
    oindex=find(cond) ; % Finds the indexes of the previous copies. 
    tempcost= t_gcost(q3(oindex)); % Extracts gcost
    if   tempcost <  ip.gcost  % Compares gcost
        check = 0;  % Blocks the state
    else
        o(oindex)=zeros(size(oc));  % Continues with the state removing the previous copies. 
       % oc=oc;
        
    end
end
end

