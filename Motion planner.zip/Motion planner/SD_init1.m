%% This script is to load motion Primitive Library to simulink
WorldChanged=1;
%% Initializing parameters

% Motion primitives generated for this path planner is for the vehicle with
% the following specification:
L_0f    =   1.686;     % Wheelbase of streetdrone [m]

% mp      =   struct('ti',[],'di',[],'tf',[],'df',[],'gcost',[],'hcost',[],'dir',[]);  


%% The HAN Parking Deck scenario.
% Creating obstacles
% We have to define the vertices which when joined forms the obstacle. 
obsc=2; % Number of obstacles
% Please put the obstacle with most number of vertices as the first obstacle. 
obsx(1,:) = [-1 -2 -2 165 165 164 164 -1];
obsy(1,:) = [-2.5 -2.5 -8.5 -8.5 -2.5 -2.5 -7.5 -7.5];
%obsx(1,:) = [70 73 73 70];
%obsy(1,:) = [10.5 10.5 8.5 8.5 ];
%obsy(1,:) = [7.5-17.5 7.5-17.5 1-17.5 1-17.5 7.5-17.5 7.5-17.5 2-17.5 2-17.5 5-17.5 5-17.5 2-17.5 2-17.5 5-17.5 5-17.5 2-17.5 2-17.5 5-17.5 5-17.5 2-17.5 2-17.5];
%obsx(1,:) = [2 1 1 168 168 167 167 110.5 110.5 110 110 107.5 107.5 107 107 104.5 104.5 104 104 2];
% Adding 2nd obstacle
 temp1   =   zeros(1,length(obsx(1,:)));                                     % Matching the number of elements
  ind     =   find([-1 -2 -2 165 165 164 164 -1]);            % Assigning the indexes     
  temp1(ind)  =   [-1 -2 -2 165 165 164 164 -1];%[1 2 2 104 104 104.5 104.5 107 107 107.5 107.5 110 110 110.5 110.5 167 167 168 168 1];              % Putting the obstacle coordinates
  obsx(2,:)   =   temp1;                                                      % Putting in the obstacle matrix. 
% 
  temp1   =   zeros(1,length(obsy(1,:)));
  ind     =   find([2.5 2.5 8.5 8.5 2.5 2.5 7.5 7.5]);
  temp1(ind)  =   [2.5 2.5 8.5 8.5 2.5 2.5 7.5 7.5];%[12.5-17.5 12.5-17.5 17.5-17.5 17.5-17.5 14.5-17.5 14.5-17.5 17.5-17.5 17.5-17.5 14.5-17.5 14.5-17.5 17.5-17.5 17.5-17.5 14.5-17.5 14.5-17.5 17.5-17.5 17.5-17.5 12.5-17.5 12.5-17.5 18.5-17.5,18.5-17.5];
  obsy(2,:)   =   temp1;

% % % Adding 3rd obstacle
%  temp1   =   zeros(1,length(obsx(1,:)));
%  ind     =   find([85,87,87,85]);
%  temp1(ind)  =   [87,89,89,87];
%  obsx(3,:)   =   temp1;
% 
%  temp1   =   zeros(1,length(obsy(1,:)));
%  ind     =   find([7,7,4,4]);
%  temp1(ind)  =   [-7,-7,-4,-4];
%  obsy(3,:)   =   temp1;
%  %Adding 4rd obstacle
%  temp1   =   zeros(1,length(obsx(1,:)));
%  ind     =   find([90.5,92.5,92.5,90.5]);
%  temp1(ind)  =   [92,93.5,93.5,92];
%  obsx(4,:)   =   temp1;
% 
% temp1   =   zeros(1,length(obsy(1,:)));
% ind     =   find([-7,-7,-4,-4]);
% temp1(ind)  =   [-7,-7,-4,-4];
% obsy(4,:)   =   temp1;
% % % % Adding 5rd obstacle
% temp1   =   zeros(1,length(obsx(1,:)));
% ind     =   find([85,87,87,85]);
% temp1(ind)  =   [85,87,87,85];
% obsx(3,:)   =   temp1;
% 
% temp1   =   zeros(1,length(obsy(1,:)));
% ind     =   find(([-1.2,-1.2,1.2,1.2]));
% temp1(ind)  =   [-1.2,-1.2,1.2,1.2];
% obsy(3,:)   =   temp1;
% % % If there are more obstacles add them in this fashion and update the 
% % obstacle count.

   figure(1);
   %subplot(211)
  hold on;
 for i=1:obsc
      obsxtemp=obsx(i,:);
   obsytemp=obsy(i,:);
     obsxtemp=obsxtemp(obsxtemp~=0);
     obsytemp=obsytemp(obsytemp~=0);
     fill(obsxtemp,obsytemp,'r');
 end
 xlim([-5 170])
 ylim([-10 10])
%  %%
%  figure(3)
% plot(x(:,1),y(:,1),'red','Linewidth',2);
% hold on
% plot(x(:,110),y(:,110),'black','Linewidth',2);
% hold on
% plot(x(:,2),y(:,2),'red','Linewidth',2);
% hold on
% plot(x(:,3),y(:,3),'red','Linewidth',2);
% hold on
% plot(x(:,4),y(:,4),'red','Linewidth',2);
% hold on
% plot(x(:,5),y(:,5),'red','Linewidth',2);
% hold on
% plot(x(:,6),y(:,6),'red','Linewidth',2);
% hold on
% legend('Parallel primitives','Straight primitives','Location','best');
% hold off
% grid on;
% xlim([0 35]);
% ylim([-5.5 5.5]);
% xlabel('x (m)');ylabel('y(m)');


%% Gain Parameters of controller
steer_sens =4;                                               % steering sensitivity 
lookahead_time = 0.5;                                          %Look-ahed time
lookahead_time_rev = 0.9;                                        %Look-ahed time reverse
Ki=1/100;                                                      % Integral gain
Kp=2;                                                          % propotional gain
steer_ratio=1;                                                 %steer Ratio


%% Loading Multibody model dimensions&parameters
Rco = 2.71; %cm
Rci = 2.31; %cm
%Rco = 1.5; %cm
%Rci = 0.75; %cm
dr = Rco-Rci; %cm
Lc = 25; %cm 
cyl_xsec = [0 -Lc/2; Rco -Lc/2; 
            Rco Lc/2; Rci Lc/2; 
            Rci -Lc/2+dr; 0 -Lc/2+dr]; %cm
Lp = 15; %cm 
%Lp1 = 18.064; %cm
piston_xsec = [0 -Lp/2; Rci -Lp/2; Rci Lp/2; 0 Lp/2]; %cm (front)
%piston_xsec1 = [0 -Lp1/2; Rci -Lp1/2; Rci Lp1/2; 0 Lp1/2]; %cm (rear)

%
Rp=0.56; %radius of pinion in cm
SA=120; %Steering angle
Del=SA*Rp*pi/180; %Steering angle in radians

%
load('Front_brake.mat');
load('Rear_brake.mat');
load('TPS_0.mat');