
%%
figure(2)
plot(out.driver_pos(3:1760,1),out.driver_pos(3:1760,2),'red',out.SD_pos(:,3),out.SD_pos(:,4),'black','LineWidth',2);
xlabel('X [meters]');
ylabel('Y [meters]');
title('Trajectory profile lane change');
legend('Trajectory (Reference)','Trajectory (Multibody)','Location','best');
xlim([0 150]);
ylim([-8 8]);
grid on;

%%
figure(3)
plot(out.tout,out.Calc_Fz_front,'black',out.tout,out.act_Fz_front,'red','LineWidth',1.5);
xlabel('time(s)');
ylabel('N');
legend('Calculated','Actual');
title('Fz-Front');
grid on;
%%
figure(4)
plot(out.tout,out.Calc_Fz_rear,'black',out.tout,out.act_Fz_rear,'red','LineWidth',1.5);
xlabel('time(s)');
ylabel('N');
legend('Calculated','Actual');
title('Fz-Rear');
grid on;
%%
figure(5)
plot(out.tout,out.calc_Fx_RL,'black',out.tout,out.actual_Fx_RL,'red','LineWidth',1.5);
xlabel('time(s)');
ylabel('N');
legend('Calculated','Actual');
title('Fx-RL');
grid on;
%%
figure(6)
plot(out.tout,out.calc_Fx_RR,'black',out.tout,out.actual_Fx_RR,'red','LineWidth',1.5)
xlabel('time(s)');
ylabel('N');
legend('Calculated','Actual')
title('Fx-RR');
grid on;
%%
figure(7)
plot(out.tout,out.Calc_Fx_vehicle,'black',out.tout,out.actual_Fx_vehicle,'red','LineWidth',1.5);
xlabel('time(s)');
ylabel('N');
legend('Calculated','Actual');
title('Fx-Total');
grid on;

%%
figure(8)
plot(out.tout,out.tau,'black','LineWidth',1.5);
xlabel('time(s)');
ylabel('Nm');
title('Motor torque vs time');
grid on;
%%
figure(9)
plot(out.tout,out.actual,'red',out.tout-0.4,out.SD_vel,'black','LineWidth',2);
xlabel('time [seconds]');
ylabel('velocity [m/s]');
title('Velocity profile for lane change');
legend('Velocity (Reference)','Velocity (Multibody)','Location','best');
xlim([0 23]);
ylim([0 12]);
grid on;
%%
figure(10);
yyaxis right
plot(out.tout,out.throttle,'red--','LineWidth',1.5)
xlabel('time [s]');ylabel('%')
%ylim([-0.5 1.1])
yyaxis left
plot(out.tout,out.tau,'black','LineWidth',1.5)
xlabel('time [s]');ylabel('Nm')
%ylim([-100 80])
legend('Regenerative Motor torque','Throttle position','Location','best')
title('Regenerative Motor torque & TPS vs time')
grid on

%%
figure(11)
plot(out.tout,out.varinf1(:,3),'black',out.tout,out.varinf2(:,3),'red',out.tout,out.varinf3(:,3),'green',out.tout,out.varinf4(:,3),'magenta','LineWidth',1.5);
xlabel('time(s)');
ylabel('N');
legend('FL','FR','RL','RR','Location','best');
title('Fz');
%xlim([0 102]);
%ylim([1000 2500]);
grid on;

%%
figure(12)
yyaxis left
plot(out.tout,out.throttle,'black','LineWidth',2);
xlabel('sec');
ylabel('-');
yyaxis right
plot(out.tout,out.brake_pr,'Red','LineWidth',2);
xlabel('sec');
ylabel('bar');
legend('Throttle pedal position','Brake pressure','Location','best');
title('TPS and Brake pr vs time');
%xlim([0 105]);
%ylim([-10 10]);
grid on;
%%
figure(13)
plot(out.X_SD,out.Y_SD,'black','LineWidth',2);
xlabel('meters');
ylabel('meters');
title('Street Drone path');
xlim([0 130]);
%ylim([0 16]);
grid on;
%%
figure(14)
plot(out.tout,out.Act_Ax,'red','LineWidth',2);
xlabel('sec');
ylabel('m/s2');
title('Long acc vs time');
%xlim([0 33]);
ylim([-5 5]);
grid on;
%%
figure(15)
plot(out.tout,out.Actual_Vel*3.6,'red','LineWidth',2);
xlabel('sec');
ylabel('km/hr');
title('Act Vel vs time');
%xlim([0 105]);
%ylim([-1 60]);
grid on;

%%
figure(16)
plot(out.tout,out.ay,'red','LineWidth',2);
xlabel('sec');
ylabel('m/s-2');
title('Lat Acc vs time');
%xlim([0 105]);
ylim([-6 6]);
grid on;
%%
figure(17)
plot(out.tout,out.Yaw,'red','LineWidth',2);
xlabel('sec');
ylabel('rad/sec');
title('Yaw rate vs time');
%xlim([0 105]);
ylim([-1.5 1.5]);
grid on;
%%
figure(18)
plot(out.tout,out.del_road_wheel,'red','LineWidth',2);xlabel('sec');
ylabel('degrees');
title('Steering angle vs time');
%xlim([0 105]);
%ylim([-1.5 1.5]);
grid on;
