clear all; clc;
%% This loop is created for me to create several MP.  ACADO toolbox is needed to run this file.
%In this example path is created constraining the orientation angle and
%steering angle. by initial angles are zero and discrtizing the final
%orintation angle (tfin)s
tini=0; %initial orientation angle
yini=0; %%initial steering  angle
for j=1: length(tini(1))
    folder=strcat('Motion_primitives_example/theta_',num2str(wrapTo360(tini(j))),'delta0'); %give folder name
    mkdir (folder); % Making folder
    yd=[3,-3,4,-4,5,-5]; 
    %thetad=0;
    for i= 1: length(yd)
        yfin= yd(i);     % Specifying end theta in degree
        dfin = 0;          % Specifying end delta  in degree        
%         file=strcat(folder,'\','mp_',num2str(wrapTo360(tfin)),'_',num2str(dfin),'.mat');
        file=strcat(folder,'\','mp_y=',num2str(yfin),'.mat');
        chk= exist (file);  % Check if MP already exists.
        if chk == 0
 
%% This is the actual ACADO code which is necessary. 
            BEGIN_ACADO;                                % Always start with "BEGIN_ACADO". 

                acadoSet('problemname', 'Motion_primitive');     % Set your problemname. If you 
                                                                % skip this, all files will
                                                                % be named "myAcadoProblem"


                DifferentialState       x y theta delta omega  vy r   ;   % The differential states
                Control                 u ;                            % The controls
                Parameter               T;                            % We would like to minize the T, so T is a parameter



                %% Differential Equation
                f = acado.DifferentialEquation(0,T);       % Set the differential equation objectfolder

                % Initialize vehicle model % add your K.E. of articulated
                % vehicle here
                v = 10;      % Velocity = +1/-1 forward/reverse [m/sec], consstant velocity
                Lf = 1;   % a [m]
                Lr = 1.686-Lf; % b [m]
                rf = 0.2651; 
                rr = 0.2811;
                Calfaf = 63000;
                Calfar = 53076;
                m=720;
                Iz=340;
%               alfaf=(((vy+(Lf*rf))/v)-delta);
% %             alfar=((vy-(Lr*rr))/v);
%               Fyf=-Calfaf*alfaf;
%               Fyr=-Calfar*alfar;
               
                
                f.add(dot(x) == (v*cos(theta))-(vy*sin(theta)));
                f.add(dot(y) == (v*sin(theta))+(vy*cos(theta)));
                f.add(dot(theta) == r);
                f.add(dot(delta) == omega);
                f.add(dot(omega) == u);  
                f.add(dot(vy) == (((-Calfaf*(((vy+(Lf*r))/v)-delta)/m)*cos(delta))+((-Calfar*(vy-(Lr*r))/v)/m)-(v*r)));
                f.add(dot(r) == (((-Calfaf*(((vy+(Lf*r))/v)-delta)*cos(delta))*(Lr/Iz))-(-Calfar*((vy-(Lr*r))/v))*(Lr/Iz)));
%               f.add(dot(x) == v*cos(theta));
%               f.add(dot(y) == v*sin(theta));
%               f.add(dot(theta) == (v/L)*tan(delta));
               
                %f.add(dot(v)==a);
            
             
        


                %% Optimal Control Problem
                ocp = acado.OCP(0.0,T); %21 is the numbe of points in the path

                ocp.minimizeMayerTerm(T);   % Minimize a Lagrange term

                ocp.subjectTo( f );                     % Your OCP is always subject to your 
                % differential equation 
                %% Initial State
                ocp.subjectTo( 'AT_START', vy == 0.0 );  % Initial condition
                ocp.subjectTo( 'AT_START', r == 0.0 );  % Initial condition
                ocp.subjectTo( 'AT_START', x == 0.0 );  % Initial condition
                ocp.subjectTo( 'AT_START', y ==0.0  );  % Initial condition
                ocp.subjectTo( 'AT_START', theta == 0.0);  % Initial condition
                ocp.subjectTo( 'AT_START', delta == 0.0);  % Initial condition
                ocp.subjectTo( 'AT_START', omega == 0.0 );  % Initial condition
               % ocp.subjectTo( 'AT_START', v == 2);  % Initial condition
               


                %final state
                %ocp.subjectTo( 'AT_END'  , x == 5 );
                ocp.subjectTo( 'AT_END'  , y == (yfin));
                ocp.subjectTo( 'AT_END'  , vy == 0.0);
                ocp.subjectTo( 'AT_END'  , r == 0.0);
                ocp.subjectTo( 'AT_END'  , theta == 0.0 );
                ocp.subjectTo( 'AT_END'  , delta == 0.0 );
                ocp.subjectTo( 'AT_END'  , omega== 0.0 );

%constraints
                %ocp.subjectTo( 0 <= theta <=0.0000000001 );
                %ocp.subjectTo( 0 <= vy <=0.00000001 );
                ocp.subjectTo( -deg2rad(40) <= delta <= deg2rad(40) ); %steering angle
                ocp.subjectTo( -0.2 <= omega <= 0.2); %steering rate in rad/s
                ocp.subjectTo( -20 <= u <= 20 ); %steering acceleration inrad/s^2
                ocp.subjectTo( 0.1 <= T <=10);  %parameter to optimize (here it's length)
                % ocp.subjectTo( -1 <= a <=1);
              



                %% Optimization Algorithm
                algo = acado.OptimizationAlgorithm(ocp); % Set up the optimization algorithm

                algo.set('DISCRETIZATION_TYPE','COLLOCATION');
                algo.set('MAX_NUM_ITERATIONS' , 300) ; 
                algo.set( 'KKT_TOLERANCE', 1);
                algo.set( 'INTEGRATOR_TYPE' , 'INT_BDF' ) ;
                algo.set( 'INTEGRATOR_TOLERANCE' , 1e-1) ;
                algo.set( 'ABSOLUTE_TOLERANCE' , 1e-1) ;
                algo.set( 'HESSIAN_APPROXIMATION' , 'EXACT_HESSIAN' );




            END_ACADO;           % Always end with "END_ACADO".  
                                 % This will generate a file problemname_ACADO.m. 
                                 % Run this file to get your results. You can

                                 % run the file problemname_ACADO.m as many
                                 % times as you want without having to compile again.



            out = Motion_primitive_RUN();% Run the test
% ACADO code ends here.
 %path is store in out.STATES (t,x,y,theta,delta omega) respectively 
 %pathlength in T=out.PARAMETER(1,2)
            
 %file=strcat(folder,'\','mp_',num2str(wrapTo360(tfin)),'_',num2str(dfin),'.mat'); 
 file=strcat(folder,'\','mp_y=',num2str(yfin),'.mat');
            save (file,'out'); % Save file of MP
        end
    end
end

        
 
